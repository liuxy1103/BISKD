/// \mainpage
/// # Graphs and Graph Algorithms in C++
///
/// http://www.andres.sc/graph.html

